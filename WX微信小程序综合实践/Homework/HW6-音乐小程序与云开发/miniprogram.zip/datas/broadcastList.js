var json = [
    {
        name: "个性电台",
        thumb: "https://y.qq.com/music/common/upload/t_music_radio/1261958.jpg?max_age=2592000"
    },
    {
        name: "随心听",
        thumb: "https://y.qq.com/music/common/upload/t_music_radio/1260297.jpg?max_age=2592000"
    },
    {
        name: "经典",
        thumb: "https://y.qq.com/music/common/upload/t_music_radio/2054444.jpg?max_age=2592000"
    },
    {
        name: "网络流行",
        thumb: "https://y.qq.com/music/common/upload/t_music_radio/2054505.jpg?max_age=2592000"
    },

    {
        name: "抖音神曲",
        thumb: "https://y.qq.com/music/common/upload/t_music_radio/2054458.jpg?max_age=2592000"
    },
    {
        name: "深度催眠",
        thumb: "https://y.qq.com/music/common/upload/t_music_radio/3188826.jpg?max_age=2592000"
    },
    {
        name: "情感治愈站",
        thumb: "https://y.qq.com/music/common/upload/t_music_radio/2929760.jpg?max_age=2592000"
    },
    {
        name: "KTV必点歌",
        thumb: "https://y.qq.com/music/common/upload/t_music_radio/2054525.jpg?max_age=2592000"
    },
    {
        name: "精选招牌歌",
        thumb: "https://y.qq.com/music/common/upload/t_music_radio/2054526.jpg?max_age=2592000"
    },
    {
        name: "热门翻唱",
        thumb: "https://y.qq.com/music/common/upload/t_music_radio/2054491.jpg?max_age=2592000"
    }
]

module.exports = {
    broadcasts: json
}